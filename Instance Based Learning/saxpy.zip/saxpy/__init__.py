"""SAX stack implementation."""

__version__ = '0.1.0'
__author__ = 'Pavel Senin <seninp@gmail.com>'
__all__ = []
